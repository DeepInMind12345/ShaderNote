﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Management.Instrumentation;
using UnityEditor;
using UnityEngine;

public class Editor_MonsterEffectParams : ScriptableObject
{
    public const string STORAGE_PATH = "Assets/Resources_Dev_OnlyArtEditorUse/DesignerEditor/Designer_Monster_EffectParams.asset";

    public AnimationCurve flashCurve = new AnimationCurve();

    public AnimationCurve iceFadeInCurve = new AnimationCurve();
    public AnimationCurve iceFadeOutCurve = new AnimationCurve();

    //public AnimationCurve dissolveFadeInCurve = new AnimationCurve();
    //public AnimationCurve dissolveFadeOutCurve = new AnimationCurve();

    public AnimationCurve fireFadeInCurve = new AnimationCurve();
    public AnimationCurve fireFadeOutCurve = new AnimationCurve();

    public static Editor_MonsterEffectParams Instance { 
        get {

            CreateOrGetInstance();
            return mInstance; 
        } 
    }
    private static Editor_MonsterEffectParams mInstance;

    private static void CreateOrGetInstance()
    {
        string[] guids = AssetDatabase.FindAssets("t:Editor_MonsterEffectParams");
        if (guids.Length == 0)
        {
            string directorPath = Path.GetDirectoryName(Path.GetFullPath(STORAGE_PATH));
            if(!Directory.Exists(directorPath))
            {
                Directory.CreateDirectory(directorPath);
            }

            mInstance = CreateInstance<Editor_MonsterEffectParams>();
            AssetDatabase.CreateAsset(mInstance, STORAGE_PATH);
            AssetDatabase.SaveAssets();
        }
        else
        {
            mInstance = AssetDatabase.LoadAssetAtPath<Editor_MonsterEffectParams>(AssetDatabase.GUIDToAssetPath(guids[0]));
        }
    }
}
