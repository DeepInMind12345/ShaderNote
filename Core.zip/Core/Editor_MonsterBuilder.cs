﻿//using System.Collections;
//using System.Collections.Generic;
//using UnityEditor;
//using UnityEngine;

//namespace TA.Rendering
//{
//    [CustomEditor(typeof(MonsterBuilder))]
//    public class Editor_MonsterBuilder : Editor
//    {
//        MonsterBuilder actualTarget;
//        private Renderer[] renderers;

//        public AnimationCurve flashCurve;

//        public AnimationCurve iceFadeInCurve;
//        public AnimationCurve iceFadeOutCurve;

//        //public AnimationCurve dissolveFadeInCurve = new AnimationCurve();
//        //public AnimationCurve dissolveFadeOutCurve = new AnimationCurve();

//        public AnimationCurve fireFadeInCurve;
//        public AnimationCurve fireFadeOutCurve;

//        private void OnEnable()
//        {
//            actualTarget = (MonsterBuilder)target;

//            if (actualTarget)
//            {
//                renderers = actualTarget.GetComponentsInChildren<Renderer>(true);

//                //foreach (var item in renderers)
//                //{
//                //    if (actualTarget.use_Flash)
//                //    {

//                //    }
//                //}
//            }

//            Debug.Log("Trigger Enable");

//            flashCurve = Editor_MonsterEffectParams.Instance.flashCurve;

//            //dissolveFadeInCurve = Editor_MonsterEffectParams.Instance.dissolveFadeInCurve;
//            //dissolveFadeOutCurve = Editor_MonsterEffectParams.Instance.dissolveFadeOutCurve;

//            iceFadeInCurve = Editor_MonsterEffectParams.Instance.iceFadeInCurve;
//            iceFadeOutCurve = Editor_MonsterEffectParams.Instance.iceFadeOutCurve;

//            fireFadeInCurve = Editor_MonsterEffectParams.Instance.fireFadeInCurve;
//            fireFadeOutCurve = Editor_MonsterEffectParams.Instance.fireFadeOutCurve;
//        }

//        public bool isFinish = false;
//        protected bool isFinishFlag = false;
//        public override void OnInspectorGUI()
//        {
//            //base.OnInspectorGUI();

//            actualTarget.use_Flash = EditorGUILayout.Toggle("Use Flash", actualTarget.use_Flash);
//            this.flashCurve = EditorGUILayout.CurveField("Flash Curve", this.flashCurve);
//            if (actualTarget.use_Flash)
//            {
//                foreach (var item in renderers)
//                {
//                    FlashMonsterEffectElement flash = item.GetComponent<FlashMonsterEffectElement>();
//                    if (flash == null)
//                    {
//                        flash = item.gameObject.AddComponent<FlashMonsterEffectElement>();
//                    }
//                    flash.animationCurve = flashCurve;
//                }
//            }
//            else
//            {
//                foreach (var item in renderers)
//                {
//                    FlashMonsterEffectElement flash = item.GetComponent<FlashMonsterEffectElement>();
//                    if (flash != null)
//                    {
//                        Object.DestroyImmediate(flash);
//                    }
//                }
//            }
//            /*
//            EditorGUILayout.Space();
//            actualTarget.use_Dissolve = EditorGUILayout.Toggle("Use Dissolve", actualTarget.use_Dissolve);
//            this.dissolveFadeInCurve = EditorGUILayout.CurveField("Dissolve FadeOut Curve", this.dissolveFadeInCurve);
//            this.dissolveFadeOutCurve = EditorGUILayout.CurveField("Dissolve FadeOut Curve", this.dissolveFadeOutCurve);
//            if (actualTarget.use_Dissolve)
//            {
//                foreach (var item in renderers)
//                {
//                    DissolveMonsterEffectElement dissolve = item.GetComponent<DissolveMonsterEffectElement>();
//                    if (dissolve == null)
//                    {
//                        dissolve = item.gameObject.AddComponent<DissolveMonsterEffectElement>();
//                    }
//                    dissolve.fadeInanimationCurve = dissolveFadeInCurve;
//                    dissolve.fadeOutanimationCurve = dissolveFadeOutCurve;
//                }
//            }
//            else
//            {
//                foreach (var item in renderers)
//                {
//                    DissolveMonsterEffectElement dissolve = item.GetComponent<DissolveMonsterEffectElement>();
//                    if (dissolve != null)
//                    {
//                        Object.DestroyImmediate(dissolve);
//                    }
//                }
//            }
//            */

//            EditorGUILayout.Space();
//            actualTarget.use_Ice = EditorGUILayout.Toggle("Use Ice", actualTarget.use_Ice);
//            this.iceFadeInCurve = EditorGUILayout.CurveField("Ice FadeIn Curve", this.iceFadeInCurve);
//            this.iceFadeOutCurve = EditorGUILayout.CurveField("Ice FadeOut Curve", this.iceFadeOutCurve);
//            if (actualTarget.use_Ice)
//            {
//                foreach (var item in renderers)
//                {
//                    IceMonsterEffectElement ice = item.GetComponent<IceMonsterEffectElement>();
//                    if (ice == null)
//                    {
//                        ice = item.gameObject.AddComponent<IceMonsterEffectElement>();
//                    }
//                    ice.fadeInanimationCurve = iceFadeInCurve;
//                    ice.fadeOutanimationCurve = iceFadeOutCurve;
//                }
//            }
//            else
//            {
//                foreach (var item in renderers)
//                {
//                    IceMonsterEffectElement ice = item.GetComponent<IceMonsterEffectElement>();
//                    if (ice != null)
//                    {
//                        Object.DestroyImmediate(ice);
//                    }
//                }
//            }

//            EditorGUILayout.Space();
//            actualTarget.use_Fire = EditorGUILayout.Toggle("Use Fire", actualTarget.use_Fire);
//            this.fireFadeInCurve = EditorGUILayout.CurveField("Fire FadeIn Curve", this.fireFadeInCurve);
//            this.fireFadeOutCurve = EditorGUILayout.CurveField("Fire FadeOut Curve", this.fireFadeOutCurve);
//            if (actualTarget.use_Fire)
//            {
//                foreach (var item in renderers)
//                {
//                    FireMonsterEffectElement fire = item.GetComponent<FireMonsterEffectElement>();
//                    if (fire == null)
//                    {
//                        fire = item.gameObject.AddComponent<FireMonsterEffectElement>();
//                    }
//                    fire.fadeInanimationCurve = fireFadeInCurve;
//                    fire.fadeOutanimationCurve = fireFadeOutCurve;
//                }
//            }
//            else
//            {
//                foreach (var item in renderers)
//                {
//                    FireMonsterEffectElement fire = item.GetComponent<FireMonsterEffectElement>();
//                    if (fire != null)
//                    {
//                        Object.DestroyImmediate(fire);
//                    }
//                }
//            }

//            EditorGUILayout.Space(20);

//            if (GUILayout.Button("调试完成，写回配置", GUILayout.Width(500), GUILayout.Height(50)))
//            {
//                Editor_MonsterEffectParams.Instance.flashCurve = flashCurve;

//                //Editor_MonsterEffectParams.Instance.dissolveFadeInCurve = dissolveFadeInCurve;
//                //Editor_MonsterEffectParams.Instance.dissolveFadeOutCurve = dissolveFadeOutCurve;

//                Editor_MonsterEffectParams.Instance.iceFadeInCurve = iceFadeInCurve;
//                Editor_MonsterEffectParams.Instance.iceFadeOutCurve = iceFadeOutCurve;

//                Editor_MonsterEffectParams.Instance.fireFadeInCurve = fireFadeInCurve;
//                Editor_MonsterEffectParams.Instance.fireFadeOutCurve = fireFadeOutCurve;

//                //Editor_MonsterEffectParams.Instance.SetDirty();
//                EditorUtility.SetDirty(Editor_MonsterEffectParams.Instance);
//                AssetDatabase.SaveAssets();
//            }
//        }
//    }
//}