﻿//#if UNITY_EDITOR
//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;
//using UnityEditor;
///// <summary>
///// Lhw+ 对自动导入的fbx替换standard shader
///// </summary>
//public class Editor_ReplaceStandardShader : AssetPostprocessor
//{
//    public static void OnPostprocessAllAssets(string[] importedAssets, string[] deletedAssets, string[] movedAssets, string[] movedFromAssetPaths)
//    {

//        for (int i = 0; i < importedAssets.Length; i++)
//        {
//            string importedAssetPath = importedAssets[i];
//            if (importedAssetPath.EndsWith(".FBX") || importedAssetPath.EndsWith(".fbx"))
//            {
//                ModelImporter importer = ModelImporter.GetAtPath(importedAssetPath) as ModelImporter;

//                var sources = new List<Renderer>();
//                string path = importedAssetPath;
//                var assets = AssetDatabase.LoadAllAssetsAtPath(path);
//                for (var j = 0; j < assets.Length; j++)
//                {
//                    var source = assets[j] as Renderer;
//                    if (source != null)
//                    {
//                        sources.Add(source);
//                    }

//                }

//                bool hasStandard = false;
//                //所有material
//                var keys = new Dictionary<string, bool>();
//                foreach (var render in sources)
//                {
//                    foreach (var mat in render.sharedMaterials)
//                    {
//                        if (mat != null && !keys.ContainsKey(mat.name) && mat.shader.name.ToLower().Contains("standard"))
//                        {
//                            hasStandard = true;
//                            break;
//                        }
//                    }
//                }
//                //替换为默认material
//                if (hasStandard)
//                {
//                    importer.materialImportMode = ModelImporterMaterialImportMode.ImportStandard;
//                    importer.SaveAndReimport();
//                    ReplaceStandardMaterial.ChangeMaterial(importer);
//                }
//                else
//                {
//                    Debug.Log("资源通过,不需要Replace Standard");
//                }
//            }    
//        }
//    }


//    public void CallMenuDynamic()
//    {
//        string menu = "CONTEXT/ModelImporter/ReplaceStandard";
//        ModelImporter importer = assetImporter as ModelImporter;
//        ExecuteMenuItemOnGameObjects(menu, new Object[] { importer });
//    }

//    static bool ExecuteMenuItemOnGameObjects(string menu, Object[] objects)
//    {
//        var flags = System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static;
//        var method = typeof(EditorApplication).GetMethod("ExecuteMenuItemWithTemporaryContext", flags);
//        var value = method.Invoke(null, new object[] { menu, objects });
//        Debug.LogError((bool)value);
//        return (bool)value;
//    }
//}
//#endif