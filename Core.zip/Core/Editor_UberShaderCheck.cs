﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;
using System.Linq;

public class Editor_UberShaderCheck : Editor
{
    public static string UberEffectPath = "Assets/EffectUberCheck.txt";
    public static string PROJ_EFF_PATH = "/Resources_Dev/Art/Effects";

    [MenuItem("Assets/TA/编辑器核心工具/筛查用了Uber Shader的特效")]
    public static void CheckEffectUberShader()
    {
        DirectoryInfo dirInfo = new DirectoryInfo(Application.dataPath + PROJ_EFF_PATH);
        FileInfo[] fileInfos = dirInfo.GetFiles("*.prefab", SearchOption.AllDirectories);

        List<string> lines = new List<string>();
        foreach (var fileInfo in fileInfos)
        {
            string assetPath = fileInfo.FullName.Substring(fileInfo.FullName.IndexOf("Assets"));
            GameObject go = AssetDatabase.LoadAssetAtPath<GameObject>(assetPath);
            var instanceGo = GameObject.Instantiate<GameObject>(go);
            ParticleSystem[] pss = instanceGo.GetComponentsInChildren<ParticleSystem>(true);
            foreach (var ps in pss)
            {
                var r = ps.GetComponent<Renderer>();
                if (r)
                {
                    if (r.sharedMaterial)
                    {
                        var shader = r.sharedMaterial.shader;
                        if (shader.name.Contains("EffectUber"))
                        {
                            string line = go.name;
                            line += "   ";
                            line += r.sharedMaterial.name;
                            lines.Add(line);
                            Debug.LogError("fine one material......" + r.sharedMaterial.name);
                        }
                    }
                }
            }
            GameObject.DestroyImmediate(instanceGo);

        }

        File.WriteAllLines(UberEffectPath, lines.ToArray());
    }
}
