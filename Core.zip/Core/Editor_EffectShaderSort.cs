﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;
using System.Linq;

public class Editor_EffectShaderSort : Editor
{
    public class ShaderElement
    {
        public string shader;
        public string prefab;
        public string material;
        public int count;
    }



    public static string eff_path = "/Resources_Dev/Art/Effects";
    public static string fileConfig = "/shaderCount.csv";
    public static string prefabFileConfig = "/prefabEffect.csv";


    [MenuItem("Assets/TA/编辑器核心工具/特效Shader排序")]
    public static void SortEffectShaders()
    {
        Dictionary<string, int> shaderDict = new Dictionary<string, int>();
        List<string> prefabInfoList = new List<string>();
        prefabInfoList.Add(string.Format("{0},{1},{2}", "prefab","材质","shader"));

        DirectoryInfo dirInfo = new DirectoryInfo(Application.dataPath + eff_path);
        FileInfo[] fileInfos = dirInfo.GetFiles("*.prefab", SearchOption.AllDirectories);
        foreach (var file in fileInfos)
        {
            string assetPath = file.FullName.Substring(file.FullName.IndexOf("Assets"));
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(assetPath);
            if (prefab)
            {
                var instanceGo = GameObject.Instantiate<GameObject>(prefab);
                var pss = instanceGo.GetComponentsInChildren<ParticleSystem>(true);
                foreach (var ps in pss)
                {
                    var renderer = ps.GetComponent<Renderer>();
                    if (renderer)
                    {
                        var mat = renderer.sharedMaterial;
                        if (mat)
                        {
                            Shader shader = mat.shader;
                            if (shaderDict.ContainsKey(shader.name))
                            {
                                shaderDict[shader.name]++;
                            }
                            else
                            {
                                shaderDict.Add(shader.name, 1);
                            }

                            prefabInfoList.Add(string.Format("{0},{1},{2}", prefab.name, mat.name, shader.name));
                        }
                    }
                }

                DestroyImmediate(instanceGo);
            }
        }

        var dict = shaderDict.OrderByDescending(o=>o.Value).ToDictionary(p=>p.Key, o=>o.Value);

        List<string> lines = new List<string>();
        lines.Add("shader名字,用到的个数");
        foreach (var item in dict)
        {
            string line = string.Format("{0},{1}",item.Key,item.Value);
            lines.Add(line);
        }
        File.WriteAllLines(Application.dataPath+fileConfig, lines);

        File.WriteAllLines(Application.dataPath + prefabFileConfig, prefabInfoList.ToArray());
    }
}
